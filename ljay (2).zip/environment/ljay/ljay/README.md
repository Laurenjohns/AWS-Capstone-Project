# LJAY

A Pen created on CodePen.io. Original URL: [https://codepen.io/laurenjohnson1239/pen/poQwaGg](https://codepen.io/laurenjohnson1239/pen/poQwaGg).

